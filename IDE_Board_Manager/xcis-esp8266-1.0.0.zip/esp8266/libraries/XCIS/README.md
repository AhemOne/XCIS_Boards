# XCIS Library


An [Arduino](https://arduino.cc/) library for accessing the XCIS feature set when adding XCIS boards and selecting options within the Arduino GUI.

## Compatible Hardware

[XCIS](http://www.xcis.com.au) based boards including:
[Gateway/Node/Device](http://www.xcis.com.au/products/LoRaNet.html)

## Installation

### Using the Arduino IDE Library Manager

XCISduino is installed automatically when the board profiles are installed.

## API

See [API.md](API.md).

## Examples

See [examples](examples) folder.

## FAQ

**1) What do I need to set up manually?**

The Serial link, if being used to debug, currently still needs to be set up manually. An option to automatically start the serial link may be added later, however until further time can be dedicated it seems attempting to use it before `setup()` is called causes the system to crash.

*the system currently works by defining a user_init() function which in turn initialises all the XCIS libraries. This function is called just before the arduino program calls setup() and enters loop(). It may be a matter of just calling Serial.begin(freq) with a defined frequency (chosen in menu) and leaving it, however this means code must be debugged in setup before being stripped of debug info and moved into the user_init() function.*

... More will be added as found.

## License

This libary is closed source. See the XCIS [license](LICENSE) for more information.
