// auto-initialisation file
#ifndef INIT_H
#define INIT_H

#include <XCISduino.h>
#include <Link.h>
#include <SPIMemory.h>
#include <Battery.h>

#ifdef LORA_ENABLED
#include <SPI.h>
#include <LoRa.h>
#endif

// we're going to create our own variant initialisation to be automatically called in main()
void initVariant();

// and make a function to report the boot code in a human readable format, this gets sent to XCIS_DEBUG_PORT
#ifdef XCIS_DEBUG
void XCIS_initReport(Stream & stream = XCIS_DEBUG_PORT);
#else
void XCIS_initReport(Stream & stream);
#endif

// prototype inits for non-XCIS libraries
int XCIS_LORA_INIT();

// global var indicates wether boot was successful or not
extern unsigned int xcis_boot_code;

#endif
