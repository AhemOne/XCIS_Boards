#ifndef HARDWARE_DEF_h
#define HARDWARE_DEF_h

#define PIN_DOES_NOT_EXIST (-1)

#ifndef NET_SO
# define NET_SO PIN_DOES_NOT_EXIST
#endif

#ifndef NET_SI
# define NET_SI PIN_DOES_NOT_EXIST
#endif

#ifndef NET_SCK
# define NET_SCK PIN_DOES_NOT_EXIST
#endif

#ifndef NET_RX
# define NET_RX PIN_DOES_NOT_EXIST
#endif

#ifndef NET_TX
# define NET_TX PIN_DOES_NOT_EXIST
#endif

#ifndef NET_INT0
# define NET_INT0 PIN_DOES_NOT_EXIST
#endif

#ifndef NET_INT1
# define NET_INT1 PIN_DOES_NOT_EXIST
#endif

#ifndef NET_D4
# define NET_D4 PIN_DOES_NOT_EXIST
#endif

#ifndef NET_D5
# define NET_D5 PIN_DOES_NOT_EXIST
#endif

#ifndef NET_D6
# define NET_D6 PIN_DOES_NOT_EXIST
#endif

#ifndef NET_D7
# define NET_D7 PIN_DOES_NOT_EXIST
#endif

#ifndef NET_D8
# define NET_D8 PIN_DOES_NOT_EXIST
#endif

#ifndef NET_D9
# define NET_D9 PIN_DOES_NOT_EXIST
#endif

#ifndef NET_D10
# define NET_D10 PIN_DOES_NOT_EXIST
#endif

#ifndef NET_V_BUS
# define NET_V_BUS PIN_DOES_NOT_EXIST
#endif

#ifndef NET_A1
# define NET_A1 PIN_DOES_NOT_EXIST
#endif

#ifndef NET_A2
# define NET_A2 PIN_DOES_NOT_EXIST
#endif

#ifndef NET_A3
# define NET_A3 PIN_DOES_NOT_EXIST
#endif

#ifndef NET_A6
# define NET_A6 PIN_DOES_NOT_EXIST
#endif

#ifndef NET_A7
# define NET_A7 PIN_DOES_NOT_EXIST
#endif

#ifndef NET_SDA
# define NET_SDA PIN_DOES_NOT_EXIST
#endif

#ifndef NET_SCL
# define NET_SCL PIN_DOES_NOT_EXIST
#endif

#ifndef NET_WP
# define NET_WP PIN_DOES_NOT_EXIST
#endif

#ifdef XCISDUINO_ENABLED
// Connect XCISDuino pins to net
#define PIN_XCIS_MISO NET_SO
#define PIN_XCIS_MOSI NET_SI
#define PIN_XCIS_SCK NET_SCK
#define PIN_XCIS_RX NET_RX
#define PIN_XCIS_TX NET_TX
#define PIN_XCIS_A1 NET_A6
#define PIN_XCIS_A2 NET_A2
#define PIN_XCIS_A3 NET_A3
#define PIN_XCIS_A6 NET_A6
#define PIN_XCIS_A7 NET_A7
#define PIN_XCIS_D4 NET_D4
#define PIN_XCIS_D5 NET_D5
#define PIN_XCIS_D9 NET_D9
#define PIN_XCIS_D10 NET_D10
#define PIN_XCIS_SDA NET_SDA
#define PIN_XCIS_SCL NET_SCL
#endif

#ifdef UPLINK_ENABLED
//#include <XCISLink.h>
#define PIN_UPLINK_CLOCK NET_INT0
#define PIN_UPLINK_DATA NET_D6
#endif

#ifdef DOWNLINK_ENABLED
//#include <XCISLink.h>
#define PIN_DOWNLINK_CON NET_D8
#define PIN_DOWNLINK_CLOCK NET_INT1
#define PIN_DOWNLINK_DATA NET_D7
#endif


#ifdef ROM_ENABLED
// known ROM types
# define ROM_25AA02UID 1
# define ROM_SST25VF080 2
# define ROM_MX25R8035F 3

#define PIN_ROM_SI NET_SI
#define PIN_ROM_SO NET_SO
#define PIN_ROM_SCK NET_SCK
#define PIN_ROM_WP NET_WP
#define PIN_ROM_CE NET_D9
#define PIN_ROM_HOLD NET_D10

# if ROM_ID == ROM_25AA02UID
#  warning 25AA02UID attached
# elif ROM_ID == ROM_SST25VF080
#  warning SST25VF080 attached
# elif ROM_ID == ROM_MX25R8035F
#  warning MX25R8035F attached
# else
#  error Attached ROM is unidentified
# endif
#endif

#ifdef BATTERY_ENABLED
# define VBUS NET_V_BUS;
#endif


#ifdef LORA_ENABLED
// known LoRa types
#define LORA_RF95 1

// known LoRa frequencies
#define LORA_915 915E6

# define PIN_LORA_SI NET_SI
# define PIN_LORA_SO NET_SO
# define PIN_LORA_SCK NET_SCK
# define PIN_LORA_SS NET_D4
# define PIN_LORA_RESET NET_D5
# define PIN_LORA_INT NET_INT0

# if LORA_ID == LORA_RF95
#  if LORA_FREQUENCY == LORA_915
#   define LORA_RF95_915
#  endif
# endif
#endif

#endif /* hardware_def_h */
