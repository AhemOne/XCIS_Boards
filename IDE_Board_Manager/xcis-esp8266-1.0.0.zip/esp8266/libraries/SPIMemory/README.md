# SPIMemory

An [Arduino](https://arduino.cc/) library for accessing the SPI UUID Memory on XCIS boards.

## Compatible Hardware

[XCIS](http://www.xcis.com.au) based boards including:
[Node](http://www.xcis.com.au/products/LoRaNet.html)
*[Gateway](http://www.xcis.com.au/products/LoRaNet.html)

*Not yet supported - for flash access

## Installation

### Using the Arduino IDE Library Manager

SPIMemory is installed automatically when the board profiles are installed.

## API

See [API.md](API.md).

## Examples

See [examples](examples) folder.

## FAQ

**1) ?**

No answer.

**2) What is required to support other memory modules?**

The current system should be abstracted so an object representing the memory type is given. Most SPI memory modules use a very similar scheme to access the data, however note that if a unique identifier is used it the number set it comes from should be considered so ensure there is no overlap and the number remains unique. The number set used for the unique node identifier is taken from a pool of numbers unique to all Microchip UID family chips (The current intalled chip is the *25AA02UID*).

**3) Can I write to the memory?**

This is possible but not currently supported because there is EEPROM available on the Atmega328p.

## License

This libary is closed source. See the XCIS [license](LICENSE) for more information.
