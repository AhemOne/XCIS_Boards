#include <SPIMemory.h>

#ifdef ROM_ENABLED

int XCIS_ROM_INIT() {
  return uid.begin();
}

ROM uid;

#else

int XCIS_ROM_INIT() { return 0; }

#endif

