# Battery API

## Include Library

```arduino
#include <Battery.h>
```

## Usage

### readVoltage

Reads the voltage of the V_BUS rail. The V_BUS rail is diode connect to the internal battery, the XCISduino VIN pin, the DC in connector and shared across the other devices connected by the XCIS link.

```arduino
Battery.readVoltage();
```

Returns a floating point value representing the voltage read.
