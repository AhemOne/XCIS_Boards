# XCISduino

An [Arduino](https://arduino.cc/) library for accessing the XCISduino header on XCIS boards.

## Compatible Hardware

 [XCIS](http://www.xcis.com.au) based boards including:
   [Gateway/Node/Device](http://www.xcis.com.au/products/LoRaNet.html)

### XCISduino Pins

| `XCISduino.`name | Description |
| :---------------------: | :------:|
| `RX`  |  `Serial` RX/Digital pin |
| `TX`  |  `Serial` TX/Digital pin |
| `MISO`  |  `SPI` MISO pin |
| `MOSI`  |  `SPI` MOSI pin |
| `SCK`  |  `SPI` SCK pin |
| `SDA`  |  `Wire` (I2C) SDA/Digital pin |
| `SCL`  |  `Wire` (I2C) SCL/Digital pin |
| `A1`  |  Analog in/Digital |
| `A2`  |  Analog in/Digital |
| `A3`  |  Analog in/Digital |
| `A6`  |  Analog in only |
| `A7`  |  Analog in only |
| *`D4`  |  Analog out/Digital |
| *`D5`  |  Analog out/Digital |
| *`D9`  |  Analog out/Digital |
| *`D10`  |  Analog out/Digital |

## Installation

### Using the Arduino IDE Library Manager

XCISduino is installed automatically when the board profiles are installed.

## API

See [API.md](API.md).

## Examples

See [examples](examples) folder.

## FAQ

**1) What is the limited set?**

The XCISduino header is mainly aimed at `Device` setups, however the `Node` has some pins free. These are accessible when using the limited set.

**2) Do I have to use the XCISduino structure?**

While its not nessicary it does not use any extra memory and ensures the correct pins are used, even if a board gets revised.

**3) Can I use A6 and A7 as digital pins?**

This depends on the microcontroller being used. The Atmega328p used in the `Node` and `Device` do not provide digital drivers on these pins and can be damaged by attempting to use as digital pins.


## License

This libary is closed source. See the XCIS [license](LICENSE) for more information.
