// Copyright (c) Sandeep Mistry. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.

#ifndef XCISDUINO_H
#define XCISDUINO_H

#include <XCIS.h>

int XCIS_XCISDUINO_INIT();

#ifdef XCISDUINO_ENABLED

struct xcisduino {
  static constexpr int RX = PIN_XCIS_RX;
  static constexpr int TX = PIN_XCIS_TX;
  static constexpr int SDA = PIN_XCIS_SDA;
  static constexpr int SCL = PIN_XCIS_SCL;
  static constexpr int MOSI = PIN_XCIS_MOSI;
  static constexpr int MISO = PIN_XCIS_MISO;
  static constexpr int SCK = PIN_XCIS_SCK;
  static constexpr int A1 = PIN_XCIS_A1;
  static constexpr int A2 = PIN_XCIS_A2;
  static constexpr int A3 = PIN_XCIS_A3;
  static constexpr int A6 = PIN_XCIS_A6;
  static constexpr int A7 = PIN_XCIS_A7;

#ifndef XCISDUINO_LIMITED
  static constexpr int D4 = PIN_XCIS_D4;
  static constexpr int D5 = PIN_XCIS_D5;
  static constexpr int D9 = PIN_XCIS_D9;
  static constexpr int D10 = PIN_XCIS_D10;
#endif
  
};

extern xcisduino XCISduino;
#endif
#endif
