# XCISduino API

The XCISduino API provides an XCISduino object which may be used to address the pins on the XCISduino header. This ensures the correct pin is used regardless of the pin routing from the board (eg pin `10` may not correspond to `D10` on the XCISduino header).

## Include Library

```arduino
#include <XCISduino.h>
```

## Usage

### XCISduino Object

```arduino
XCISduino.pin_name
```
Where `pin_name` is any of the following:
`RX` - `Serial` RX/Digital pin
`TX` - `Serial` TX/Digital pin
`MISO` - `SPI` MISO pin
`MOSI` - `SPI` MOSI pin
`SCK` - `SPI` SCK pin
`SDA` - `Wire` (I2C) SDA/Digital pin
`SCL` - `Wire` (I2C) SCL/Digital pin
`A1` - Analog in/Digital
`A2` - Analog in/Digital
`A3` - Analog in/Digital
`A6` - Analog in only
`A7` - Analog in only
*`D4` - Analog out/Digital
*`D5` - Analog out/Digital
*`D9` - Analog out/Digital
*`D10` - Analog out/Digital
* not available on limited set

## Examples

### GPIO
```arduino
pinMode(XCISduino.D9, OUTPUT);
digitalWrite(XCISduino.D9, HIGH);
pinMode(XCISduino.D10, INPUT);
int error_flag = digitalRead(XCISduino.D10);

if (error_flag) {
  digitalWrite(XCISduino.D9, LOW);
}
```

### Analog Input
```arduino
int accel_x = analogRead(XCISduino.A1);
int accel_y = analogRead(XCISduino.A2);
int accel_z = analogRead(XCISduino.A3);

int accel_mag = sqrt(accel_x * accel_x + accel_y + accel_y + accel_z * accel_z);
```

### Analog Output
```arduino
pinMode(XCISduino.D9, OUTPUT);

int water_height = analogRead(XCISduino.A1);
int pump_power = 0;

if (water_height < 1024) {                // when water is under (about) 1m;
  pump_power = 255 - (water_height / 4);  // turn on the pump more when closer to empty
}
analogWrite(XCISduino.D9, pump_power);
```

### Serial
```arduino
Serial.begin(115200);

Serial.println("Hello World!");
```

### SPI
```arduino
#include <SPI.h>

static constexpr int SPI_SS = XCISduino.D4;

pinMode(SPI_SS, OUTPUT);      // set up SS pin
digitalWrite(SPI_SS, HIGH);

SPI.begin();

SPISettings SPI_parameters = SPISettings(100000, MSBFIRST, SPI_MODE0);

SPI.beginTransaction(SPI_parameters);
digitalWrite(SPI_SS, LOW);
SPI.write(0x12);              // request REG 12
int value = SPI.write(0x00);  // read result

digitalWrite(SPI_SS, HIGH);
SPI.endTransaction();

if (value != 0x56) while (1); // invalid result, lock up
```

### I2C
No I2C devices have been tested.

```arduino
#include <Wire.h>

// ???
```
