// XCIS board routing profile

#ifndef ROUTING_H
#define ROUTING_H

#include "undef_routing.h"

// we want to overlap the SPI pins going to LoRa and flash because they both sit on the same SPI bus when configured as a Node.
#define NET_SO (7)
#define NET_SI (8)
#define NET_SCK (6)

// however, in the mean time since this needs a lot of debugging and the hardware hack works, we can attach HSPI
//#define NET_SO PIN_SPI_MISO
//#define NET_SI PIN_SPI_MOSI
//#define NET_SCK PIN_SPI_SCK

#define NET_RX (3)
#define NET_TX (1)
#define NET_INT0 (0)
#define NET_INT1 (12)
#define NET_D4 (4)
#define NET_D5 (5)
//#define NET_D6 (6)
//#define NET_D7 (7)
//#define NET_D8 (8)
#define NET_D9 (9) /* mem_hold */
#define NET_D10 (10) /* mem_wp */
//#define NET_D11 (11)
#define NET_D12 (12)
#define NET_D13 (13)
//#define NET_D14 (14)
#define NET_D15 (15)
#define NET_D16 (16)
#define NET_V_BUS PIN_A0
//#define NET_A1 PIN_A1
//#define NET_A2 PIN_A2
//#define NET_A3 PIN_A3
//#define NET_A6 PIN_A6
//#define NET_A7 PIN_A7
#define NET_SDA PIN_WIRE_SDA
#define NET_SCL PIN_WIRE_SCL

#define NET_WP (10)

#endif /* ROUTING_H */
