// XCIS board un-routing profile. Because the ESP core seems to include the user files before pins_arduino.h, it predefines all the NETs as not existing. If we notice this we should remove the troublesome definitions and redefine what we need

#ifndef UNDEF_ROUTING_H
#define UNDEF_ROUTING_H

#undef NET_SO
#undef NET_SI
#undef NET_SCK
#undef NET_RX
#undef NET_TX
#undef NET_INT0
#undef NET_INT1
#undef NET_D4
#undef NET_D5
#undef NET_D9
#undef NET_D10
#undef NET_D12
#undef NET_D13
#undef NET_D15
#undef NET_D16
#undef NET_V_BUS
#undef NET_SDA
#undef NET_SCL
#undef NET_WP

#endif /* ROUTING_H */
