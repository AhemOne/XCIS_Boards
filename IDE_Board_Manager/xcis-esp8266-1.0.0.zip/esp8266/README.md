XCIS ESP8266 Package
===========================================

# Contents
- [Installation](#installation)
- [Documentation](#documentation)
- [Issues](#issues)
- [Build](#build)

## Installation
### Set Preferences
Start Arduino and open the Preferences window.

### XCIS avr Package
Add ```blahblahblah/package.json``` to the *Additional Board Manager URLs* field.

### Install Boards
Open Boards Manager from Tools > Board menu and install *XCIS ESP8266 Boards* platform.

### 24 MHz Patch
In order to make the 24 MHz version of the Gateway work correctly the esp8266 core needs to be patched. Go to your 
`C:\Users\<username>\AppData\Local\Arduino15\packages\esp8266\hardware\esp8266` (Windows) or `~/Library/Arduino15/packages/esp8266/hardware/esp8266` (Mac) folder. Open the latest version folder then open the `cores > esp8266` folder. Open the `core_esp8266_phy.cpp` file and find the following lines;

```
#if F_CRYSTAL == 40000000
/*[48] =*/ 0,
#else
/*[48] =*/ 1,
#endif
```

Replace it with;

```
#if F_CRYSTAL == 40000000
/*[48] =*/ 0,
#elif F_CRYSTAL == 24000000
/*[48] =*/ 2,
#else
/*[48] =*/ 1,
#endif
```

**note** esptool.py has also been patched by replacing `norm_xtal = 40 if est_xtal > 33 else 24` with `norm_xtal = 40 if est_xtal > 33 else 26 if est_xtal > 25 else 24`. This has already been done to the supplied version, however if updated future versions may require the same patch.


## Documentation
[Documentation](blahblahblah/github) to the latest version.

## Usage
### Select Board
Select the appropriate platform from Tools > Board.

### Upload
Connect an Serial programmer to RX and TX then apply power to the board and/or connect USB to the Serial programmer. Click the Upload icon or select Sketch > Upload.

#### Serial Connections
Ensure the Serial programmer RX connects to the board TX and Serial programmer TX to the board RX.

#### External Power
If the board is powered externally to the Serial programmer a common ground must be maintained between the Serial programmer and the board.

## Issues
Many.


### To Do
- trim libraries which arent needed

## Build
move library content to folder *avr* and zip using `zip xcis-esp8266-vers.zip -r ./esp8266/`. Do not include version number folder, this is done by the installer. **note: vers is version number. eg xcis-esp8266-1.2.0.zip**

perform checksum on zip using `shasum -a 256 xcis-esp8266-vers.zip`. *SHA256 is preferred*

find size of zip using `ls -l | grep xcis-esp8266`.

Append a new version to the *package_xcis_index.json* file on Github, update version numbers, checksums, sizes, filenames and etc.

Upload *xcis-esp8266-vers.zip* to Github. *note: max. file size 25 megabytes*
