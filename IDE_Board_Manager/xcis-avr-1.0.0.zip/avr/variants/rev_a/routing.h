// XCIS board routing profile

#ifndef ROUTING_H
#define ROUTING_H

#define NET_SO PIN_SPI_MISO
#define NET_SI PIN_SPI_MOSI
#define NET_SCK PIN_SPI_SCK
#define NET_RX (0)
#define NET_TX (1)
#define NET_INT0 (2)
#define NET_INT1 (3)
#define NET_D4 (4)
#define NET_D5 (5)
#define NET_D6 (6)
#define NET_D7 (7)
#define NET_D8 (8)
#define NET_D9 (9)
#define NET_D10 (10)
#define NET_V_BUS PIN_A0
#define NET_A1 PIN_A1
#define NET_A2 PIN_A2
#define NET_A3 PIN_A3
#define NET_A6 PIN_A6
#define NET_A7 PIN_A7
#define NET_SDA PIN_WIRE_SDA
#define NET_SCL PIN_WIRE_SCL

#endif /* ROUTING_H */
