# Battery

An [Arduino](https://arduino.cc/) library for accessing the main power voltage reading on XCIS boards.

## Compatible Hardware

[XCIS](http://www.xcis.com.au) based boards including:
[Node](http://www.xcis.com.au/products/LoRaNet.html)
[Device](http://www.xcis.com.au/products/LoRaNet.html)
*[Gateway](http://www.xcis.com.au/products/LoRaNet.html)

* Currently untested

## Installation

### Using the Arduino IDE Library Manager

Battery is installed automatically when the board profiles are installed.

## API

See [API.md](API.md).

## Examples

See [examples](examples) folder.

## FAQ

**1) What voltage does the reading represent?**

The reading is of the **V_BUS** rail (see schematic). This rail is shared amongst all devices attached to the XCIS links (i.e. connected to the Uplink/Downlink connections). This rail is energised by various inputs which are diode protected *(D1, D4, D5)*, which are the battery, DC input and XCISduino VIN pin.

**2) What is the purpose of the XCISduino VIN pin?**

This pin allows an XCISduino shield to be attached with its own power source. This means a shield could be designed which has its own power supply that can also be used to power the rest of the system. Such an example of use might be in designing a pump controller. A pump would quickly overwhelm the capabilities of the internal Node battery so a capable power system would be designed to run it. This power supply can then be fed to the XCISduino VIN pin and used to power the entire system, furthermore in this arrangement the need for a solar panel and battery on the node is made redundant.

## License

This libary is closed source. See the XCIS [license](LICENSE) for more information.
