#include <Arduino.h>
#include <Battery.h>

#ifdef BATTERY_ENABLED

int XCIS_BATTERY_INIT() { return 1; }

float battery::readVoltage() {
  float var = (float) analogRead(A0);
  var *= 0.05;
  return var;
}

struct battery Battery;

#else

int XCIS_BATTERY_INIT() { return 0; }

#endif

