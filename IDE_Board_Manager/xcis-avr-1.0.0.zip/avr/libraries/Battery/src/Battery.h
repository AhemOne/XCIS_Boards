// Copyright (c) Sandeep Mistry. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.

#ifndef BATTERY_H
#define BATTERY_H

int XCIS_BATTERY_INIT();

struct battery {
  float readVoltage();
};

#ifdef BATTERY_ENABLED
extern struct battery Battery;
#endif

#endif
