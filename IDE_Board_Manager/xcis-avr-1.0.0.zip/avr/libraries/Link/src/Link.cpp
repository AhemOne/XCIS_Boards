int XCIS_UPLINK_INIT() {
#ifdef UPLINK_ENABLED
  return 1;
#else
  return 0;
#endif
}
int XCIS_DOWNLINK_INIT() {
#ifdef DOWNLINK_ENABLED
  return 1;
#else
  return 0;
#endif
}
