// Copyright (c) Sandeep Mistry. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.

#ifndef LINK_H
#define LINK_H

int XCIS_UPLINK_INIT();
int XCIS_DOWNLINK_INIT();

#ifdef UPLINK_ENABLED
// extern uplink
#endif

#ifdef DOWNLINK_ENABLED
// extern downlink
#endif

#endif
