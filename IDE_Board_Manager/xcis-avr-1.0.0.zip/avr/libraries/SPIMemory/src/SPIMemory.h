// Copyright (c) Sandeep Mistry. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.

#ifndef ROM_H
#define ROM_H

#include <Arduino.h>
#include <XCIS.h>
#include <SPI.h>

int XCIS_ROM_INIT();

template <unsigned int SS>
class UUID {
  enum INSTRUCTIONS {
    WRSR = 0x01,
    WRITE = 0x02,
    READ = 0x03,
    WRDI = 0x04,
    RDSR = 0x05,
    WREN = 0x06,
  };
  
  // EEPROM device locations
  struct LOCATION_E { enum {
    START = 0x00,
    SOFT_END = 0xB9,
    HARD_END = 0xFF,
    MANUFACTURER_ID = 0xFA,
    DEVICE_ID = 0xFB,
    SN_32 = 0xFC,
    SN_48 = 0xFA,
    SN_64 = 0xF8,
    SN_128 = 0xF0,
    SN_256 = 0xE0,
    // END => declared SOFT_END, HARD_END or integer value <= 0xFF in using statement below
    END_OF_FILE = HARD_END + 1,
  }; };
  // EEPROM Locations may be the entire EEPROM (HARD_END), safe write protected UID (SOFT_END), or user defined (INT), see datasheet for more info
  template <int _END> struct LOCATION_T : public LOCATION_E { enum { END = _END }; };
  using LOCATION = LOCATION_T<LOCATION_E::SOFT_END>;
  
  struct sreg_data {
    unsigned int WriteInProgress : 1;
    unsigned int WriteEnabled : 1;
    unsigned int Protected : 2;
  };
  
  struct sreg : sreg_data {
    union su {
      sreg_data data;
      unsigned int i;
    };
    
    sreg() {
      su * reg = *this;
      (*reg).i = 0;
    }
  };
  
  SPISettings settings;
  
protected:
  int longRead(char * buffer, const int from, int n) {
    if ( buffer != nullptr ) {
      SPI.beginTransaction(settings);
      digitalWrite(SS, LOW);
      SPI.transfer(READ);
      SPI.transfer(from);
      for (int i = 0; i < n; i++) buffer[i] = SPI.transfer(0x00);
      digitalWrite(SS, HIGH);
      SPI.endTransaction();
    }
    return n;
  }
  
  sreg readSREG() {
    SPI.beginTransaction(settings);
    digitalWrite(SS, LOW);
    SPI.transfer(READ);
    char data = SPI.transfer(0x00);
    digitalWrite(SS, HIGH);
    SPI.endTransaction();
    
    sreg parsed;
    parsed.WriteInProgress = (0x01 & data);
    parsed.WriteEnabled = (0x02 & data) >> 1;
    parsed.Protected = (0x0C & data) >> 2;
    return parsed;
  }
  
  template <int n> int SNn(char * buffer) {
    static constexpr int s = n/8;
    return longRead(buffer, LOCATION::END_OF_FILE - s, s);
  }
  
public:
  UUID() {
    pinMode(SS, OUTPUT);
    settings = SPISettings(100000, MSBFIRST, SPI_MODE0);
    digitalWrite(SS, HIGH);
  }
  
  int begin() {
    SPI.begin();
    return testProductID() && testManufacturerID();
  }
  
  int getData(char * buffer = nullptr, int from = 0, int to = 0) {
    return longRead(buffer, from, to - from);
  }
  
  int getProductID(char * buffer) {
    return longRead(buffer, LOCATION::DEVICE_ID, 1);
  }
  
  int getManufacturerID(char * buffer) {
    return longRead(buffer, LOCATION::MANUFACTURER_ID, 1);
  }
  
  int getAllData(char * buffer) {
    return getData(buffer, LOCATION::START, LOCATION::HARD_END);
  }
  
  int getUserData(char * buffer) {
    return getData(buffer, LOCATION::START, LOCATION::SOFT_END);
  }
  
  bool testProductID() {
    char data;
    getProductID(&data);
    return data == 0x51;
  }
  
  bool testManufacturerID() {
    char data;
    getManufacturerID(&data);
    return data == 0x29;
  }
  
  int SN32(char * buffer) { return SNn<32>(buffer); }
  int id(char * buffer) { return SN32(buffer); }
  int SN48(char * buffer) { return SNn<48>(buffer); }
  int SN64(char * buffer) { return SNn<64>(buffer); }
  int SN128(char * buffer) { return SNn<128>(buffer); }
  int SN256(char * buffer) { return SNn<256>(buffer); }
};

#ifdef ROM_ENABLED

typedef UUID<PIN_ROM_CE> ROM;
extern ROM uid;

#endif
#endif
