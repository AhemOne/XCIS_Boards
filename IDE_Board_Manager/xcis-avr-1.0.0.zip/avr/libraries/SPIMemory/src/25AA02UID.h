// Copyright (c) Sandeep Mistry. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.

#ifndef ROM_25AA02UID_H
#define ROM_25AA02UID_H

struct ROM_25AA02UID_DEF {
  
};


#endif
