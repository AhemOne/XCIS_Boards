# SPIMemory API

## Include Library

```arduino
#include <SPIMemory.h>
```

## Usage

### getData

Fill a buffer with a contiguous stream of data from the memory offsets `from` to `to`.

```arduino
SPIMemory.getData(buffer, from, to);
```
* `buffer` - a `char` array to be filled with the data read from the memory device
* `from` - Starting memory offset
* `to` - Ending memory offset

Returns the number of bytes read.

### getProductID

Fill a buffer with a contiguous stream of data representing the memory modules product ID. The size is dependent on the memory chip used.

```arduino
SPIMemory.getProductID(buffer);
```
* `buffer` - a `char` array to be filled with the data read from the memory device.

Returns the number of bytes read. If `nullptr` is passed to `buffer` the size of the data array will be returned.

### getManufacturerID

Fill a buffer with a contiguous stream of data representing the memory modules manufacturer ID. The size is dependent on the memory chip used.

```arduino
SPIMemory.getManufacturerID(buffer);
```
* `buffer` - a `char` array to be filled with the data read from the memory device.

Returns the number of bytes read. If `nullptr` is passed to `buffer` the size of the data array will be returned.

### getAllData

Fill a buffer with a contiguous stream of data the entire contents of the memory chip. This should be used with caution on smaller microcontrollers.

```arduino
SPIMemory.getAllData(buffer);
```
* `buffer` - a `char` array to be filled with the data read from the memory device.

Returns the number of bytes read. If `nullptr` is passed to `buffer` the size of the data array will be returned.

### getUserData

Fill a buffer with a contiguous stream of data the section of the memory chip designated to user data. This should be used with caution on smaller microcontrollers.

```arduino
SPIMemory.getAllData(buffer);
```
* `buffer` - a `char` array to be filled with the data read from the memory device.

Returns the number of bytes read. If `nullptr` is passed to `buffer` the size of the data array will be returned.

### testProductID

Tests if the product ID is the expected value.

```arduino
SPIMemory.testProductID();
```

Returns a boolean value `true` if passed and `false` if failed.

### testManufacturerID

Tests if the manufacturer ID is the expected value.

```arduino
SPIMemory.testManufacturerID();
```

Returns a boolean value `true` if passed and `false` if failed.

### id

Collects a unique ID of *n* bits (as defined by the memory type).

```arduino
SPIMemory.id(buffer);
```
* `buffer` - a `char` array to be filled with the data read from the memory device.

Returns the number of bytes read.

```arduino
char unique_id[4]; 
SPIMemory.id(&unique_id);
```

### SN<n>

Collects a unique ID of *n* bits. Compatible numbers are `32, 48, 64, 128, 256`.

```arduino
SPIMemory.SN{n}(buffer);
```
* `{n}` - The number of bits requested.
* `buffer` - a `char` array to be filled with the data read from the memory device.

Returns the number of bytes read.

```arduino
uint64_t unique_id; 
SPIMemory.SN64((char *) &unique_id);
```
