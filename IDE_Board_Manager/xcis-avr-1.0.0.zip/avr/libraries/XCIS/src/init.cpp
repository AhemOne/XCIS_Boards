// auto-initialisation file

#include <Arduino.h>
#include <XCIS.h>

#ifdef LORA_ENABLED

int XCIS_LORA_INIT() {
  // change the pins to the board setup and start
  LoRa.setPins(PIN_LORA_SS, PIN_LORA_RESET, PIN_LORA_INT);
  return LoRa.begin(LORA_FREQUENCY);
}

#else

int XCIS_LORA_INIT() { return 0; }

#endif

unsigned int xcis_boot_code = 0;

void XCIS_initReport(Stream & stream) {
  unsigned int code = xcis_boot_code;
  
  auto extract = [&code]() {
    int res = code & 0x01;
    code >>= 1;
    return res;
  };
  
  int lora = extract();
  int battery = extract();
  int rom = extract();
  int downlink = extract();
  int uplink = extract();
  int xcisduino = extract();
  
  auto printer = [&stream](const char name[], int state) {
    stream.print(name);
    stream.print(": ");
    stream.println(state ? "Passed" : "Failed" );
  };
  
  printer("XCISduino", xcisduino);
  printer("Uplink", uplink);
  printer("Downlink", downlink);
  printer("ROM", rom);
  printer("Battery", battery);
  printer("LoRa", lora);
}

void initVariant() {
  xcis_boot_code = 0;
  
  auto perform = [](int (*init_fcn)(void)) {
    xcis_boot_code <<= 1;
    int res = init_fcn();
    xcis_boot_code += res;
  };
  
  perform(XCIS_XCISDUINO_INIT);
  perform(XCIS_UPLINK_INIT);
  perform(XCIS_DOWNLINK_INIT);
  perform(XCIS_ROM_INIT);
  perform(XCIS_BATTERY_INIT);
  perform(XCIS_LORA_INIT);
}
