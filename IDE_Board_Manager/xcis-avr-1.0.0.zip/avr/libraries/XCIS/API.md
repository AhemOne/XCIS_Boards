# XCIS API

The XCIS library manages the inclusions for the board given the settings in the Arduino GUI. Using this library you should not have to manually include any libraries that are inherent to the board.

## Include Library

```arduino
#include <XCIS.h>
```
## Usage and Examples

### XCISduino

Please see [XCISduino](../XCISduino/).

### Link

Not Available.

### SPIMemory

Please see [SPIMemory](../SPIMemory/).

### Battery

Please see [Battery](../Battery/).

### LoRa

Please see [LoRa](../LoRa/). 

**Note:** The LoRa library is automatically set up. This means there is no need to call `LoRa.begin(...)` in the `setup()` function.

### Start-up report

A report may be produced and printed. The report will tell wether the various XCIS devices selected in the GUI have been initialised correctly. Note: Devices which are *not available* will report `failed`.

```arduino
XCIS_initReport(Stream)
```
  * `Stream` - The stream output to print to. This is automatically the **Debug** stream if selected in the GUI, otherwise may be defined at runtime.

```arduino
void setup() {
  Serial.begin(9600);
  XCIS_initReport(Serial);
}
```
