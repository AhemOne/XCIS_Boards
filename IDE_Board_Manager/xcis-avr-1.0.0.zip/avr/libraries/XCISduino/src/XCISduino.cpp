#include <XCISduino.h>

#ifdef XCISDUINO_ENABLED

int XCIS_XCISDUINO_INIT() { return 1; }

xcisduino XCISduino;

#else

int XCIS_XCISDUINO_INIT() { return 0; }

#endif
