XCIS AVR Package
===========================================

# Contents
- [Installation](#installation)
- [Documentation](#documentation)
- [Issues](#issues)
- [Build](#build)

## Installation
### Set Preferences
Start Arduino and open the Preferences window.

### XCIS avr Package
Add ```blahblahblah/package.json``` to the *Additional Board Manager URLs* field.

### Install Boards
Open Boards Manager from Tools > Board menu and install *XCIS AVR Boards* platform.

## Documentation
[Documentation](blahblahblah/github) to the latest version.

## Usage
### Select Board
Select the appropriate platform from Tools > Board.

### Upload
Connect an ISP programmer to the board and connect to USB. Select the ISP programmer port from Tools > Port. Select the option Sketch > Upload Using Programmer.

## Issues
Many.


### To Do
- trim libraries which arent needed

## Build
move library content to folder *avr* and zip using `zip xcis-avr-vers.zip -r ./avr/`. Do not include version number folder, this is done by the installer. **note: vers is version number. eg xcis-avr-1.2.0.zip**

perform checksum on zip using `shasum -a 256 xcis-avr-vers.zip`. *SHA256 is preferred*

find size of zip using `ls -l | grep xcis-avr`.

Append a new version to the *package_xcis_index.json* file on Github, update version numbers, checksums, sizes, filenames and etc.

Upload *xcis-avr-vers.zip* to Github. *note: max. file size 25 megabytes*
